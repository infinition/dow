self.DOW_BOOKMARKLETS.push(
  {
    id: 'save-paprika-recipe',
    name: 'Save Recipe to Paprika',
    description: 'Prompt for a Paprika token at runtime, then save the current recipe.',
    tags: ['Services', 'Recipe'],
    icon: 'fa-utensils',
    file: 'bookmarklets/private/save-paprika-recipe.js'
  },
  {
    id: 'empty-plex-watchlist',
    name: 'Empty Plex Watchlist',
    description: 'Prompt for a Plex token and confirm before removing every watchlist item.',
    tags: ['Services', 'Plex', 'Destructive'],
    icon: 'fa-trash-can',
    file: 'bookmarklets/private/empty-plex-watchlist.js'
  }
);