(() => {
  const token = window.prompt('Paprika API token:');
  if (!token) return;

  const script = document.createElement('script');
  script.src = `https://paprikaapp.com/bookmarklet/v1/?token=${encodeURIComponent(token)}&timestamp=${Date.now()}`;
  script.onerror = () => window.alert('Paprika could not load on this page.');
  document.body.append(script);
})();