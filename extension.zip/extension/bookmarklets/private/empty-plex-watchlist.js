(() => {
  const token = window.prompt('Plex token (used only for this run):');
  if (!token) return;
  if (!window.confirm('Remove every item from this Plex watchlist? This cannot be undone.')) return;

  (async () => {
    try {
      const response = await fetch('https://discover.provider.plex.tv/library/sections/watchlist/all', {
        headers: {
          Accept: 'application/json',
          'X-Plex-Token': token
        }
      });
      if (!response.ok) throw new Error('Plex could not load the watchlist.');

      const data = await response.json();
      const entries = data.MediaContainer?.Metadata || [];
      if (entries.length === 0) {
        window.alert('Plex watchlist is already empty.');
        return;
      }

      let removed = 0;
      for (const entry of entries) {
        if (!entry.ratingKey) continue;
        const removeResponse = await fetch(`https://discover.provider.plex.tv/actions/removeFromWatchlist?ratingKey=${encodeURIComponent(entry.ratingKey)}`, {
          method: 'PUT',
          headers: { 'X-Plex-Token': token }
        });
        if (removeResponse.ok) removed += 1;
      }
      window.alert(`Removed ${removed} item(s) from the Plex watchlist.`);
      window.location.reload();
    } catch (error) {
      window.alert(error.message || 'Plex watchlist cleanup failed.');
    }
  })();
})();